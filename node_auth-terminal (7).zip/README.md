# Node_Auth // Research_Terminal

A retro-futuristic research terminal portfolio built with React, TailwindCSS, and a glitch aesthetic.

## How to Deploy (Fixing the Black Screen)

### Option 1: Netlify (Recommended - Easiest)
Netlify is generally more reliable for Single Page Applications than GitHub Pages.

1.  **Build the project**:
    ```bash
    npm install
    npm run build
    ```
2.  **Deploy**:
    *   Go to [Netlify Drop](https://app.netlify.com/drop).
    *   Drag and drop the `dist` folder that was created in your project.
    *   That's it. Your site is live.

### Option 2: GitHub Pages (Manual)
I have updated `vite.config.ts` to use `base: './'` which should fix the black screen issue.

1.  **Build**:
    ```bash
    npm run build
    ```
2.  **Upload**:
    *   Push the contents of the `dist` folder to your GitHub repository (specifically the `gh-pages` branch if you have one, or configure Settings > Pages to point to the folder).

## How to Manage Content (The "CMS")

Since this is a serverless static site, there is no database. Content is stored in `src/data/projects.ts`.

**To add a new blog post:**

1. Run the app locally: `npm run start` (or similar command based on your tooling).
2. Navigate to `http://localhost:XXXX/#/admin`.
3. This "Hidden Admin Panel" is a tool that generates the code for you.
4. Fill out the Title, Description, and Content (HTML supported).
5. Click **Generate JSON Object**.
6. Copy the code output.
7. Open `src/data/projects.ts` in your code editor.
8. Paste the object into the `PROJECTS` array.
9. Commit and push your changes.
