import { Project } from '../types';

export const PROJECTS: Project[] = [
  // --- PROJECTS (External Links) ---
  {
    id: '1',
    type: 'project',
    refId: '#REC-001',
    title: 'Movie Recommendation System',
    description: 'CineMatch is a movie recommendation system designed to provide personalized movie suggestions. It builds on data from The Movie Database (TMDb) and MovieLens to deliver relevant recommendations.',
    content: '',
    tags: ['Python', 'Content-based filtering', 'Collaborative filtering'],
    imageUrl: 'https://picsum.photos/seed/cine/600/400?grayscale',
    externalLink: 'https://github.com',
    date: '2023.12.01',
    stats: { label: 'DATASET', value: 'TMDB' }
  },
  {
    id: '2',
    type: 'project',
    refId: '#AI-099',
    title: 'AI-Powered Burnout Coach',
    description: 'Equa is a comprehensive system for burnout detection that uses machine learning and a large language model (LLM) to provide a proactive approach to workplace wellness through analyzing key employee metrics.',
    content: '',
    tags: ['Python', 'PyTorch', 'Scikit-learn', 'LLM'],
    imageUrl: 'https://picsum.photos/seed/ai/600/401?grayscale',
    externalLink: 'https://github.com',
    date: '2023.11.15',
    stats: { label: 'MODEL', value: 'LLM' }
  },
  {
    id: '3',
    type: 'project',
    refId: '#NLP-BERT',
    title: 'Sentiment Analysis',
    description: 'A fine-grained sentiment analysis project exploring classical and modern approaches to classify subtle emotional cues. Implementations include SVMs, RNNs and logistic regression, as well as transformer-based models (BERT / DistilBERT).',
    content: '',
    tags: ['Python', 'PyTorch', 'BERT', 'DistilBERT'],
    imageUrl: 'https://picsum.photos/seed/nlp/600/402?grayscale',
    externalLink: 'https://github.com',
    date: '2023.10.10',
    stats: { label: 'ACCURACY', value: 'SOTA' }
  },
  {
    id: '4',
    type: 'project',
    refId: '#GAME-CPP',
    title: 'Pac-Man CLI',
    description: 'A Pac-Man inspired game with randomly generated maps, custom colors, and a leaderboard. Maze generation uses DFS, ghost behavior is driven by BFS, visuals are rendered using ASCII art and Unicode.',
    content: '',
    tags: ['C++', 'CLI', 'ASCII visuals', 'DFS', 'BFS'],
    imageUrl: 'https://picsum.photos/seed/game/600/403?grayscale',
    externalLink: 'https://github.com',
    date: '2023.09.05',
    stats: { label: 'LANG', value: 'C++' }
  },

  // --- TALKS (Internal Blogs) ---
  {
    id: '101',
    type: 'talk',
    refId: '#BLOG-001',
    title: 'The Ethics of AI in 2024',
    description: 'Reflecting on the responsibility of developers as AI becomes ubiquitous. How do we balance innovation with safety?',
    content: `
      <h2>The Developer's Dilemma</h2>
      <p>As we integrate LLMs into more systems, the line between helpful automation and opaque decision-making blurs. In this article, I explore the concept of "Explainable AI" (XAI) and why it matters now more than ever.</p>
      
      <h3>Key Considerations</h3>
      <ul>
        <li>Bias in training data</li>
        <li>Environmental cost of training large models</li>
        <li>The alignment problem</li>
      </ul>
      
      <p>We must ensure that the tools we build serve humanity, rather than just optimizing metrics.</p>
    `,
    tags: ['AI Ethics', 'Philosophy', 'Opinion'],
    imageUrl: 'https://picsum.photos/seed/ethics/600/400?grayscale',
    date: '2024.01.15',
    stats: { label: 'READ_TIME', value: '5 MIN' }
  }
];